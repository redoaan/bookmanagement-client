// import MyForm from "./Form/Form";
import Form2 from "./Form/Form2";

function App() {
  return (
    <div className="App">
      <header className="App-header">
        {/* <MyForm /> */}
        <Form2 />
      </header>
    </div>
  );
}

export default App;
